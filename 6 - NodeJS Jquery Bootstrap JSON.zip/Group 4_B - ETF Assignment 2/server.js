const express = require('express');
const app = express();
app.use(express.json());
app.use(express.urlencoded({extended: true}));
const bodyParser = require('body-parser');
const cors = require('cors');
app.use(cors());
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

const fs = require('fs');

function saveStudentsToJSON() {
  fs.writeFile('students.json', JSON.stringify(students), 'utf8', (err) => {
    if (err) {
      console.error('Error writing student data:', err);
    } else {
      console.log('Student data saved successfully');
    }
  });
}



//Handle Marks
let marks = [];

fs.readFile('marks.json', 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading Marks data:', err);
  } else {
    marks = JSON.parse(data);
    console.log('Marks loaded successfully');
  }
});

function savemarksToJSON() {
  fs.writeFile('marks.json', JSON.stringify(marks), 'utf8', (err) => {
    if (err) {
      console.error('Error writing Marks:', err);
    } else {
      console.log('Marks saved successfully');
    }
  });
}

app.post('/marks', (req, res) => {
  const mark = req.body;
  marks.push(mark);
  savemarksToJSON();
  res.status(201).json({ message: 'Marks inserted successfully' });
});

app.get('/marks', (req, res) => {
  res.json(marks);
});

app.get('/marks/:sid', (req, res) => {
  const sid = req.params;
  console.log(sid.sid);
  
  	var result2 = [];
	for (var i = 0; i < marks.length; i++)
	{
			if (marks[i].sid !== sid.sid)
			{
				console.log(marks[i].sid)
				result2push(marks[i]);
			}
	}
	result2.push(mark);
	console.log(result);

  res.json(result2);
});


app.post("/marks/:sid", (req, res) => {
 	
    sid = req.params;
   
   let mark=req.body;
   
   console.log(mark);
   
   console.log(sid.sid);
   
	var result = [];
	for (var i = 0; i < marks.length; i++)
	{
			if (marks[i].sid !== sid.sid)
			{
				console.log(marks[i].sid)
				result.push(marks[i]);
			}
	}
	result.push(mark);
	console.log(result);
	
	fs.writeFile('marks.json', JSON.stringify(result), 'utf8', (err) => {
    });
	
	fs.readFile('marks.json', 'utf8', (err, data) => {
	marks = JSON.parse(data);
	console.log('Marks data loaded successfully 2');	
	});
	
	});

app.delete("/marks/:sid", (req, res) => {
 	
     sid = req.params;
   
   console.log(sid.sid);
   
	var result = [];
	for (var i = 0; i < marks.length; i++)
	{
    if (marks[i].sid !== sid.sid)
    {
		console.log(marks[i].sid)
        result.push(marks[i]);
    }
	}
	
	console.log(result);
	
	fs.writeFile('marks.json', JSON.stringify(result), 'utf8', (err) => {
    if (err) {
      console.error('Error writing Marks:', err);
    } else {
      console.log('Marks saved successfully');
	  

		fs.readFile('marks.json', 'utf8', (err, data) => {
			marks = JSON.parse(data);
			console.log('Marks loaded successfully');
		});
    }
  });
});
  







// Load student records from the JSON file
let students = [];

fs.readFile('students.json', 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading student data:', err);
  } else {
    students = JSON.parse(data);
    console.log('Student data loaded successfully');
  }
});


//Load Users
let users = [];

fs.readFile('users.json', 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading User data:', err);
  } else {
    users = JSON.parse(data);
    console.log('User data loaded successfully');
  }
});

app.get('/users', (req, res) => {
  res.json(users);
});

app.get('/users/:username', (req, res) => {
  const username = req.params.username;
  const filteredusers = users.filter((s) => s.username === username);
  res.json(filteredusers);
});




// Insert a Student
app.post('/students', (req, res) => {
	
  const student = req.body;
  students.push(student);
  saveStudentsToJSON();
  res.status(201).json({ message: 'Student inserted successfully' });
});



// Show all Students
app.get('/students', (req, res) => {
  res.json(students);
});

// Find a Student by SID
app.get('/students/:sid', (req, res) => {
  const sid = req.params.sid;
  const filteredStudents = students.filter((s) => s.sid === sid);
  res.json(filteredStudents);
});



// Find Students by First Name
app.get('/students/firstname/:firstName', (req, res) => {
  const firstName = req.params.firstName;
  const filteredStudents = students.filter((s) => s.firstName === firstName);
  res.json(filteredStudents);
});

// Find Students by Last Name
app.get('/students/lastname/:lastName', (req, res) => {
  const lastName = req.params.lastName;
  const filteredStudents = students.filter((s) => s.lastName === lastName);
  res.json(filteredStudents);
});

// Find Students by Email
app.get('/students/email/:email', (req, res) => {
  const email = req.params.email;
  const filteredStudents = students.filter((s) => s.email === email);
  res.json(filteredStudents);
});

// Find Students by Nearest City
app.get('/students/city/:nearestCity', (req, res) => {
  const nearestCity = req.params.nearestCity;
  const filteredStudents = students.filter((s) => s.nearestCity === nearestCity);
  res.json(filteredStudents);
});

// Find Students by Course
app.get('/students/course/:course', (req, res) => {
  const course = req.params.course;
  const filteredStudents = students.filter((s) => s.course === course);
  res.json(filteredStudents);
});

// Find Students by Guardian
app.get('/students/guardian/:guardian', (req, res) => {
  const guardian = req.params.guardian;
  const filteredStudents = students.filter((s) => s.guardian === guardian);
  res.json(filteredStudents);
});

// Update Student by SID

app.post("/students/:sid", (req, res) => {
 	
    sid = req.params;
   
   let stu=req.body;
   
   console.log(stu);
   
   console.log(sid.sid);
   
	var result = [];
	for (var i = 0; i < students.length; i++)
	{
			if (students[i].sid !== sid.sid)
			{
				console.log(students[i].sid)
				result.push(students[i]);
			}
	}
	result.push(stu);
	console.log(result);
	
	fs.writeFile('students.json', JSON.stringify(result), 'utf8', (err) => {
    });
	
	fs.readFile('students.json', 'utf8', (err, data) => {
	students = JSON.parse(data);
	console.log('Student data loaded successfully 2');	
	});
	
	});
		
 




//Delete Student by SID the Correct one.
// Delete Student by SID
app.delete("/students/:sid", (req, res) => {
 	
     sid = req.params;
   
   console.log(sid.sid);
   
	var result = [];
	for (var i = 0; i < students.length; i++)
	{
			if (students[i].sid !== sid.sid)
			{
				console.log(students[i].sid)
				result.push(students[i]);
			}
	}
	console.log(result);
	
	       fs.writeFile('students.json', JSON.stringify(result), 'utf8', (err) => {
    if (err) {
      console.error('Error writing Students:', err);
    } 
	else 
	{
      console.log('Students saved successfully');
	  

		fs.readFile('students.json', 'utf8', (err, data) => {
			students = JSON.parse(data);
			console.log('Marks loaded successfully');
		});
    }
  });
});




// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
