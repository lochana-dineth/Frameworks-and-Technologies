
//Display all Marks
function load() {   
    $(function(){
    $.ajax({
        url: 'http:/localhost:3000/marks',
        type: 'get',
        contentType: 'application/json',             
        dataType: "json",
        
        success: function (data, textStatus, jQxhr) {
        let text = "<table class=table>";
        text +="<thead> <tr> <th scope=col>Sid</th> <th scope=col>Subject 1</th> <th scope=col>Marks</th> <th scope=col>Subject 2</th> <th scope=col>Marks</th> <th scope=col>Subject 3</th> <th scope=col>Marks</th> <th scope=col>Subject 4</th> <th scope=col>Marks</th> </thead></tr>";
        
        for (let i = 0; i < data.length; i++) {
        text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].sub1 +"</td>"+ " " + "<td>"+data[i].sub1m+"</td>"+  " " +"<td>"+ data[i].sub2 +"</td>"+ " " + "<td>"+data[i].sub2m + "</td>"+" " + "<td>"+data[i].sub3+"</td>" + " " + "<td>"+data[i].sub3m +"</td>"+ " " +"<td>"+ data[i].sub4 +"</td>"+ " " +"<td>"+ data[i].sub4m +"</td>"+"</tr>";
        }
        text += "</table>";
        document.getElementById("allmarks").innerHTML = text;
        },
        
        error: function (jqXhr, textStatus, errorThrown) {
                alert(errorThrown);
        } 
      
      });

    });
  }	


$(document).ready(function()
  {	  

//Find Marks

$('#submit_id').on('click',function(){
    var id= $('#idvalue').val();
    $.ajax({
        type: 'GET',
        url:'http:/localhost:3000/marks/'+id,
        contentType:'application/json',
        dataType:"json",
        success: function (data, textStatus, jQxhr) {
            let text = "<table class=table>";
            text +="<thead> <tr> <th scope=col>Sid</th> <th scope=col>Subject 1</th> <th scope=col>Marks</th> <th scope=col>Subject 2</th> <th scope=col>Marks</th> <th scope=col>Subject 3</th> <th scope=col>Marks</th> <th scope=col>Subject 4</th> <th scope=col>Marks</th> </thead></tr>";
            
            for (let i = 0; i < data.length; i++) {


            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].sub1 +"</td>"+ " " + "<td>"+data[i].sub1m+"</td>"+  " " +"<td>"+ data[i].sub2 +"</td>"+ " " + "<td>"+data[i].sub2m + "</td>"+" " + "<td>"+data[i].sub3+"</td>" + " " + "<td>"+data[i].sub3m +"</td>"+ " " +"<td>"+ data[i].sub4 +"</td>"+ " " +"<td>"+ data[i].sub4m +"</td>"+"</tr>";
            }
            text += "</table>";
            document.getElementById("result").innerHTML = text;
            },
            
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
    });
    });
    
    
//Find Grades 

$('#submit_grade').on('click',function(){
    var sid= $('#idvalue').val();
    $.ajax({
        type: 'GET',
        url:'http:/localhost:3000/marks/'+sid,
        contentType:'application/json',
        dataType:"json",
        success: function (data, textStatus, jQxhr) {
            let text = "<table class=table>";
            text +="<thead> <tr> <th scope=col>Sid</th> <th scope=col>Subject 1</th> <th scope=col>Grade</th> <th scope=col>Subject 2</th> <th scope=col>Grade</th> <th scope=col>Subject 3</th> <th scope=col>Grade</th> <th scope=col>Subject 4</th> <th scope=col>Grade</th> </thead></tr>";
            
            for (let i = 0; i < data.length; i++) {

            var sub1g = "null";
            var sub2g = "null";
            var sub3g = "null";
            var sub4g = "null";    

            if (data[i].sub1m > 75)
            {
                  sub1g = "A";
            }    
            else if (data[i].sub1m > 55 && data[i].sub1m<75)
            {
                  sub1g = "B";
            }
            else if (data[i].sub1m > 45 && data[i].sub1m<55)
            {
                  sub1g = "C";
            }
            else if (data[i].sub1m > 0 && data[i].sub1m<45)
            {
                  sub1g = "D";
            }

            if (data[i].sub2m > 75)
            {
                  sub2g = "A";
            }    
            else if (data[i].sub2m > 55 && data[i].sub2m<75)
            {
                  sub2g = "B";
            }
            else if (data[i].sub2m > 45 && data[i].sub2m<55)
            {
                  sub2g = "C";
            }
            else if (data[i].sub2m > 0 && data[i].sub2m<45)
            {
                  sub2g = "D";
            }


            if (data[i].sub3m > 75)
            {
                  sub3g = "A";
            }    
            else if (data[i].sub3m > 55 && data[i].sub3m<75)
            {
                  sub3g = "B";
            }
            else if (data[i].sub3m > 45 && data[i].sub3m<55)
            {
                  sub3g = "C";
            }
            else if (data[i].sub3m > 0 && data[i].sub3m<45)
            {
                  sub3g = "D";
            }


            if (data[i].sub4m > 75)
            {
                  sub4g = "A";
            }    
            else if (data[i].sub4m > 55 && data[i].sub4m<75)
            {
                  sub4g = "B";
            }
            else if (data[i].sub4m > 45 && data[i].sub4m<55)
            {
                  sub4g = "C";
            }
            else if (data[i].sub4m > 0 && data[i].sub4m<45)
            {
                  sub4g = "D";
            }

            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].sub1 +"</td>"+ " " + "<td>"+sub1g+"</td>"+  " " +"<td>"+ data[i].sub2 +"</td>"+ " " + "<td>"+sub2g + "</td>"+" " + "<td>"+data[i].sub3+"</td>" + " " + "<td>"+sub3g +"</td>"+ " " +"<td>"+ data[i].sub4 +"</td>"+ " " +"<td>"+ sub4g +"</td>"+"</tr>";
            }
            text += "</table>";
            document.getElementById("result").innerHTML = text;
            },
            
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
    });
    });
    



//Insert Marks

$('#submit_newdata').on('click',function(){
    
    $.ajax({
        type: 'POST',
        url:'http:/localhost:3000/marks/',
        contentType:'application/json',
        data:JSON.stringify
        ({
            "sid": $('#newsid').val(),
            "sub1": $('#newfname').val(), 
            "sub1m": $('#newlname').val(), 
            "sub2": $('#newemail').val(),
            "sub2m":$('#newcity').val(),
            "sub3":$('#newcourse').val(), 
            "sub3m":$("#newguardian").val() ,
            "sub4":$("#newsubject").val(),
            "sub4m":$("#newsubject2").val()  
        }),
        success:function(data)
        {
           alert("Marks is inserted");
        },
        error:function()
        {
            alert("could not insert Marks");
        }
    });
    });     



//Update
$('#update_data').on('click',function(){
	var sid= $('#newsid2u').val();
			
    $.ajax({
        type: 'POST',
        url:'http:/localhost:3000/marks/'+sid,
        contentType:'application/json',
        data:JSON.stringify
        ({
            "sid": $('#newsid2u').val(),
            "sub1": $('#newfname2').val(), 
            "sub1m": $('#newlname2').val(), 
            "sub2": $('#newemail2').val(),
            "sub2m":$('#newcity2').val(),
            "sub3":$('#newcourse2').val(), 
            "sub3m":$("#newguardian2").val() ,
            "sub4":$("#newsubject222").val(),
            "sub4m":$("#newsubject22").val()  
        }),
        success:function(data)
        {
           alert("Mark is Updated");
        },
        error:function()
        {
            alert("Could not update Marks");
        }
    });
 });   

//Delete

$('#delete_marks').on('click',function(){
    var delete_id= $('#dlid').val();
    $.ajax({
        type: 'DELETE',
        url:'http:/localhost:3000/marks/'+delete_id,
        contentType:'application/json',
        dataType:"json",
        success:function(data)
        {
           alert("Marks is inserted");
        },
        error:function()
        {
            alert("could not delete Marks");
        }
		
    });
    });    


});