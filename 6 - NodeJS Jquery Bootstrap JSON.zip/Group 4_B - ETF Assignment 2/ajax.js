
//Display all Students	
function load() {   
        $(function(){
        $.ajax({
            url: 'http:/localhost:3000/students',
            type: 'get',
            contentType: 'application/json',             
            dataType: "json",
			
            success: function (data, textStatus, jQxhr) {
            let text = "<table class=table>";
			text +="<thead> <tr> <th scope=col>sid</th> <th scope=col>First Name</th> <th scope=col>Last Name</th> <th scope=col>Email</th> <th scope=col>Near City</th> <th scope=col>Course</th> <th scope=col>Guardian</th> <th scope=col>Subjects</th> </thead></tr>";
			
            for (let i = 0; i < data.length; i++) {
            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].firstName +"</td>"+ " " + "<td>"+data[i].lastName +"</td>"+  " " +"<td>"+ data[i].email +"</td>"+ " " + "<td>"+data[i].nearestCity + "</td>"+" " + "<td>"+data[i].course+"</td>" + " " + "<td>"+data[i].guardian +"</td>"+ " " +"<td>"+ data[i].subjects +"</td>"+"</tr>";
            }
            text += "</table>";
            document.getElementById("allstudents").innerHTML = text;
            },
			
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
          
          });
 
        });
      }	


$(document).ready(function()
{	
// displaying student by id
$('#submit_id').on('click',function(){
var id= $('#idvalue').val();
$.ajax({
    type: 'GET',
    url:'http:/localhost:3000/students/'+id,
    contentType:'application/json',
    dataType:"json",
            success: function (data, textStatus, jQxhr) {
				
            let text = "<table class=table>";
			text +="<thead> <tr> <th scope=col>sid</th> <th scope=col>First Name</th> <th scope=col>Last Name</th> <th scope=col>Email</th> <th scope=col>Near City</th> <th scope=col>Course</th> <th scope=col>Guardian</th> <th scope=col>Subjects</th> </thead></tr>";
			
            for (let i = 0; i < data.length; i++) {
            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].firstName +"</td>"+ " " + "<td>"+data[i].lastName +"</td>"+  " " +"<td>"+ data[i].email +"</td>"+ " " + "<td>"+data[i].nearestCity + "</td>"+" " + "<td>"+data[i].course+"</td>" + " " + "<td>"+data[i].guardian +"</td>"+ " " +"<td>"+ data[i].subjects +"</td>"+"</tr>";
            }
            text += "</table><br/><br/>";
            document.getElementById("result").innerHTML = text;
            },
			
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
});
});


//display student by firstname
$('#submit_fname').on('click',function(){
    var fname= $('#fnamevalue').val();
    
    $.ajax({
        type: 'GET',
        url:'http:/localhost:3000/students/firstname/'+fname,
        contentType:'application/json',
        dataType:"json",
                 success: function (data, textStatus, jQxhr) {
            let text = "<table class=table>";
			text +="<thead> <tr> <th scope=col>sid</th> <th scope=col>First Name</th> <th scope=col>Last Name</th> <th scope=col>Email</th> <th scope=col>Near City</th> <th scope=col>Course</th> <th scope=col>Guardian</th> <th scope=col>Subjects</th> </thead></tr>";
			
            for (let i = 0; i < data.length; i++) {
            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].firstName +"</td>"+ " " + "<td>"+data[i].lastName +"</td>"+  " " +"<td>"+ data[i].email +"</td>"+ " " + "<td>"+data[i].nearestCity + "</td>"+" " + "<td>"+data[i].course+"</td>" + " " + "<td>"+data[i].guardian +"</td>"+ " " +"<td>"+ data[i].subjects +"</td>"+"</tr>";
            }
            text += "</table><br/><br/>";
            document.getElementById("result").innerHTML = text;
            },
			
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
    });
    });

//display student by lastname
$('#submit_lname').on('click',function(){
    var lname= $('#lnamevalue').val();
    
    $.ajax({
        type: 'GET',
        url:'http:/localhost:3000/students/lastname/'+lname,
        contentType:'application/json',
        dataType:"json",
                 success: function (data, textStatus, jQxhr) {
				
            let text = "<table class=table>";
			text +="<thead> <tr> <th scope=col>sid</th> <th scope=col>First Name</th> <th scope=col>Last Name</th> <th scope=col>Email</th> <th scope=col>Near City</th> <th scope=col>Course</th> <th scope=col>Guardian</th> <th scope=col>Subjects</th> </thead></tr>";
			
            for (let i = 0; i < data.length; i++) {
            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].firstName +"</td>"+ " " + "<td>"+data[i].lastName +"</td>"+  " " +"<td>"+ data[i].email +"</td>"+ " " + "<td>"+data[i].nearestCity + "</td>"+" " + "<td>"+data[i].course+"</td>" + " " + "<td>"+data[i].guardian +"</td>"+ " " +"<td>"+ data[i].subjects +"</td>"+"</tr>";
            }
            text += "</table><br/><br/>";
            document.getElementById("result").innerHTML = text;
            },
			
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
    });
    });

//displaying student by email
$('#submit_email').on('click',function(){
    var email= $('#Emailvalue').val();
    
    $.ajax({
        type: 'GET',
        url:'http:/localhost:3000/students/email/'+email,
        contentType:'application/json',
        dataType:"json",
             success: function (data, textStatus, jQxhr) {
				
            let text = "<table class=table>";
			text +="<thead> <tr> <th scope=col>sid</th> <th scope=col>First Name</th> <th scope=col>Last Name</th> <th scope=col>Email</th> <th scope=col>Near City</th> <th scope=col>Course</th> <th scope=col>Guardian</th> <th scope=col>Subjects</th> </thead></tr>";
			
            for (let i = 0; i < data.length; i++) {
            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].firstName +"</td>"+ " " + "<td>"+data[i].lastName +"</td>"+  " " +"<td>"+ data[i].email +"</td>"+ " " + "<td>"+data[i].nearestCity + "</td>"+" " + "<td>"+data[i].course+"</td>" + " " + "<td>"+data[i].guardian +"</td>"+ " " +"<td>"+ data[i].subjects +"</td>"+"</tr>";
            }
            text += "</table><br/><br/>";
            document.getElementById("result").innerHTML = text;
            },
			
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
    });
    });

//displaying student by Nearestcity
$('#submit_city').on('click',function(){
    var city= $('#cityvalue').val();
    
    $.ajax({
        type: 'GET',
        url:'http:/localhost:3000/students/city/'+city,
        contentType:'application/json',
        dataType:"json",
             success: function (data, textStatus, jQxhr) {
				
            let text = "<table class=table>";
			text +="<thead> <tr> <th scope=col>sid</th> <th scope=col>First Name</th> <th scope=col>Last Name</th> <th scope=col>Email</th> <th scope=col>Near City</th> <th scope=col>Course</th> <th scope=col>Guardian</th> <th scope=col>Subjects</th> </thead></tr>";
			
            for (let i = 0; i < data.length; i++) {
            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].firstName +"</td>"+ " " + "<td>"+data[i].lastName +"</td>"+  " " +"<td>"+ data[i].email +"</td>"+ " " + "<td>"+data[i].nearestCity + "</td>"+" " + "<td>"+data[i].course+"</td>" + " " + "<td>"+data[i].guardian +"</td>"+ " " +"<td>"+ data[i].subjects +"</td>"+"</tr>";
            }
            text += "</table><br/><br/>";
            document.getElementById("result").innerHTML = text;
            },
			
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
    });
    });   
    
//displaying student by guardian
$('#submit_guardian').on('click',function(){
    var guardian= $('#guardianvalue').val();
    
    $.ajax({
        type: 'GET',
        url:'http:/localhost:3000/students/guardian/'+guardian,
        contentType:'application/json',
        dataType:"json",
             success: function (data, textStatus, jQxhr) {
				
            let text = "<table class=table>";
			text +="<thead> <tr> <th scope=col>sid</th> <th scope=col>First Name</th> <th scope=col>Last Name</th> <th scope=col>Email</th> <th scope=col>Near City</th> <th scope=col>Course</th> <th scope=col>Guardian</th> <th scope=col>Subjects</th> </thead></tr>";
			
            for (let i = 0; i < data.length; i++) {
            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].firstName +"</td>"+ " " + "<td>"+data[i].lastName +"</td>"+  " " +"<td>"+ data[i].email +"</td>"+ " " + "<td>"+data[i].nearestCity + "</td>"+" " + "<td>"+data[i].course+"</td>" + " " + "<td>"+data[i].guardian +"</td>"+ " " +"<td>"+ data[i].subjects +"</td>"+"</tr>";
            }
            text += "</table><br/><br/>";
            document.getElementById("result").innerHTML = text;
            },
			
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
    });
    }); 
	
	
//displaying student by Course
$('#submit_course').on('click',function(){
    var course= $('#coursevalue').val();
    
    $.ajax({
        type: 'GET',
        url:'http:/localhost:3000/students/course/'+course,
        contentType:'application/json',
        dataType:"json",
             success: function (data, textStatus, jQxhr) {
				
            let text = "<table class=table>";
			text +="<thead> <tr> <th scope=col>sid</th> <th scope=col>First Name</th> <th scope=col>Last Name</th> <th scope=col>Email</th> <th scope=col>Near City</th> <th scope=col>Course</th> <th scope=col>Guardian</th> <th scope=col>Subjects</th> </thead></tr>";
			
            for (let i = 0; i < data.length; i++) {
            text += "<tr>" +"<th scope=row>"+ data[i].sid+"</td>" + " " +"<td>"+ data[i].firstName +"</td>"+ " " + "<td>"+data[i].lastName +"</td>"+  " " +"<td>"+ data[i].email +"</td>"+ " " + "<td>"+data[i].nearestCity + "</td>"+" " + "<td>"+data[i].course+"</td>" + " " + "<td>"+data[i].guardian +"</td>"+ " " +"<td>"+ data[i].subjects +"</td>"+"</tr>";
            }
            text += "</table><br/><br/>";
            document.getElementById("result").innerHTML = text;
            },
			
            error: function (jqXhr, textStatus, errorThrown) {
                    alert(errorThrown);
            } 
    });
    }); 

	

//inserting a student
$('#submit_newdata').on('click',function(){
    
    $.ajax({
        type: 'POST',
        url:'http:/localhost:3000/students/',
        contentType:'application/json',
        data:JSON.stringify
        ({
            "sid": $('#newsid').val(),
            "firstName": $('#newfname').val(), 
            "lastName": $('#newlname').val(), 
            "email": $('#newemail').val(),
            "nearestCity":$('#newcity').val(),
            "course":$('#newcourse').val(), 
            "guardian":$("#newguardian").val() ,
            "subjects":$("#newsubject").val() 
        }),
        success:function(data)
        {
           alert("student is inserted");
        },
        error:function()
        {
            alert("could not insert student");
        }
    });
    });     


//update and delete part not thr pls add the button for them and put their id for onclick
//and for var variable give the id of that update text box
//updating student by sid

//updating a student
$('#update_data').on('click',function(){
	var sid= $('#newsidu').val();
			
    $.ajax({
        type: 'POST',
        url:'http:/localhost:3000/students/'+sid,
        contentType:'application/json',
        data:JSON.stringify
        ({
            "sid": $('#newsidu').val(),
            "firstName": $('#newfnameu').val(), 
            "lastName": $('#newlnameu').val(), 
            "email": $('#newemailu').val(),
            "nearestCity":$('#newcityu').val(),
            "course":$('#newcourseu').val(), 
            "guardian":$("#newguardianu").val() ,
            "subjects":$("#newsubjectu").val() 
        }),
        success:function(data)
        {
           alert("student is inserted");
        },
        error:function()
        {
            alert("could not insert student");
        }
    });
 });   

	


 
	

//delete by SID
    $('#delete_id').on('click',function(){
        var id2= $('#idvalue2').val();
        $.ajax({
            type: 'DELETE',
            url:'http:/localhost:3000/students/'+id2,
            contentType:'application/json',
            dataType:"json",
            success:function(data)
            {
                alert("Deleted");
            },
            error:function()
            {
                alert("could not find student");
            }
        });
        });    
});